define({
  "_widgetLabel": "กล่องควบคุม"
});