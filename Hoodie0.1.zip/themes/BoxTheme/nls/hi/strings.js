define({
  "_themeLabel": "बॉक्स थीम",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_top": "शीर्ष लेआउट"
});