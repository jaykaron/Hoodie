define({
  "_themeLabel": "Θέμα Box",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_top": "Επάνω διάταξη"
});