define({
  "productVersion": "Ürün sürümü: ",
  "kernelVersion": "Çekirdek sürümü: ",
  "_widgetLabel": "Hakkında"
});