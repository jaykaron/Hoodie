define({
  "productVersion": "产品版本： ",
  "kernelVersion": "核版本： ",
  "_widgetLabel": "关于"
});