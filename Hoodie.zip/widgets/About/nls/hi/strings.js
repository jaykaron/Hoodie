define({
  "productVersion": "उत्पाद संस्करण: ",
  "kernelVersion": "कर्नेल संस्करण: ",
  "_widgetLabel": "बारे में"
});