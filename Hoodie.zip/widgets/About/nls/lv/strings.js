define({
  "productVersion": "Izstrādājuma versija: ",
  "kernelVersion": "Kodola versija: ",
  "_widgetLabel": "Par"
});