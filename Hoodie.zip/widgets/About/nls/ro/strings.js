define({
  "productVersion": "Versiune produs: ",
  "kernelVersion": "Versiune kernel: ",
  "_widgetLabel": "Despre"
});