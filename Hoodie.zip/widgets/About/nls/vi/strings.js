define({
  "productVersion": "Phiên bản sản phẩm: ",
  "kernelVersion": "Phiên bản Kernel: ",
  "_widgetLabel": "Về"
});