define({
  "productVersion": "Versione prodotto: ",
  "kernelVersion": "Versione kernel: ",
  "_widgetLabel": "Informazioni"
});