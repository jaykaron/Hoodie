define({
  "productVersion": "גרסת מוצר: ",
  "kernelVersion": "גרסת Kernel: ",
  "_widgetLabel": "אודות"
});