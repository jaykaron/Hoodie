define({
  "productVersion": "Версия продукта: ",
  "kernelVersion": "Версия ядра: ",
  "_widgetLabel": "Описание"
});