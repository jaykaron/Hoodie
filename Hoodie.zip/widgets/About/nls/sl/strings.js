define({
  "productVersion": "Različica produkta: ",
  "kernelVersion": "Različica jedra: ",
  "_widgetLabel": "Več o tem"
});