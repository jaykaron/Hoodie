define({
  "productVersion": "Versão do produto ",
  "kernelVersion": "Versão do Kernel: ",
  "_widgetLabel": "Sobre"
});