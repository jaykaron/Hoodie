define({
  "productVersion": "Έκδοση προϊόντος: ",
  "kernelVersion": "Έκδοση πυρήνα: ",
  "_widgetLabel": "Πληροφορίες"
});