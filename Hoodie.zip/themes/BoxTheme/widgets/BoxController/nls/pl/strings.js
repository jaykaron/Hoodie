define({
  "_widgetLabel": "Kontroler Pola"
});